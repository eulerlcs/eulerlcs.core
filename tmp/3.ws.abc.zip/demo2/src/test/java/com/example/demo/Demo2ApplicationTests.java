package com.example.demo;

import java.io.File;
import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo2ApplicationTests {

	@Test
	void hello() throws IOException {
		String fullname = getClass().getClassLoader().getResource("jsf/first.xhtml").getFile();

		Document doc = Jsoup.parse(new File(fullname), "utf-8");

//		Element head = doc.head();
//		System.out.println(head);
//		Element body = doc.body();
//		System.out.println(body);

		Elements allElements = doc.children();
		System.out.println(allElements.size());
	}
}
