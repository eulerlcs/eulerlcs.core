package com.github.eulerlcs.migration.jsf.command;

import org.springframework.stereotype.Component;

import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Component
@Command(name = "App")
public class MyCommand {

//	@Autowired
//	private SomeService someService;

	// Prevent "Unknown option" error when users use
	// the Spring Boot parameter 'spring.config.location' to specify
	// an alternative location for the application.properties file.
	@Option(names = "--spring.config.location", hidden = true)
	private String springConfigLocation;

	@Option(names = { "-x", "--option" }, description = "example option")
	private boolean flag;

	public Integer call() throws Exception {
		// business logic here
		return 0;
	}
}
