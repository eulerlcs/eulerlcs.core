package com.github.eulerlcs.hailun.jsf2thymeleaf.config;

import java.nio.file.Path;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import lombok.Data;

@Configuration
@ConfigurationProperties(prefix = "jsf.thymeleaf")
@PropertySource(value = "classpath:/data/Jsf2Thymeleaf.yml", encoding = "UTF-8", factory = CommPropertyResourceFactory.class)
@Data
public class Jsf2ThymeleafProperties {
	@Value("${jsf.thymeleaf.data.input}")
	private Path dataInput;
	@Value("${jsf.thymeleaf.data.output}")
	private Path dataOutput;
	private String subject;
	private String text;
}
