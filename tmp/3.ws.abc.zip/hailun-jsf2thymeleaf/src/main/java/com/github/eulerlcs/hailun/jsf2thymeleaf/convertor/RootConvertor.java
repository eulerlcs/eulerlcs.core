package com.github.eulerlcs.hailun.jsf2thymeleaf.convertor;

import org.springframework.stereotype.Component;

@Component
public class RootConvertor {

}
