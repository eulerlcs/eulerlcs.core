package com.github.eulerlcs.hailun.jsf2thymeleaf.command;

import java.io.IOException;
import java.nio.file.Files;
import java.util.concurrent.Callable;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;

import com.github.eulerlcs.hailun.jsf2thymeleaf.config.Jsf2ThymeleafProperties;

import lombok.extern.slf4j.Slf4j;
import picocli.CommandLine.Command;
import picocli.CommandLine.Option;

@Slf4j
@Component
@Command(name = "convert", description = { "jsf to thymeleaf CLI" })
public class RootCommand implements Callable<Integer> {

//	@Autowired
//	private SomeService someService;

	// Prevent "Unknown option" error when users use
	// the Spring Boot parameter 'spring.config.location' to specify
	// an alternative location for the application.properties file.
	@Option(names = { "-j", "--javascript.writeout" }, defaultValue = "false", hidden = true)
	private boolean jsWriteOut;

	private Jsf2ThymeleafProperties setting;

//	@Value("${spring.mail.from}")
//	private String from;

	public RootCommand(Jsf2ThymeleafProperties setting) {
		log.debug("RootCommand is created.");
		this.setting = setting;
	}

	@Override
	public Integer call() throws Exception {
		// business logic here
		log.error("RootCommand is called.");
		// String fullname =
		// getClass().getClassLoader().getResource("jsf/first.xhtml").getFile();
		Files.list(setting.getDataInput()).forEach(it -> {
			log.error(it.getFileName().toString());
			Document doc = null;
			try {
				doc = Jsoup.parse(it.getFileName().toFile(), "utf-8");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

//		Element head = doc.head();
//		System.out.println(head);
//		Element body = doc.body();
//		System.out.println(body);

			Elements allElements = doc.children();
			System.out.println(allElements.size());
		});
		return 0;
	}
}