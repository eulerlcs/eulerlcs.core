package ch07.ex2_2_2_OrderingOperators1

fun main(args: Array<String>) {
    println("abc" < "bac")
}
