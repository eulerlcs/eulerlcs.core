package ch02.ex1_1_HelloWorld

fun main(args: Array<String>) {
    println("Hello, world!")
}
