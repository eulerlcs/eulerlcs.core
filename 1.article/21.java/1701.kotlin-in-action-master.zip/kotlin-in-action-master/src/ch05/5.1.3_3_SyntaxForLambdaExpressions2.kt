package ch05.ex1_3_3_SyntaxForLambdaExpressions2

fun main(args: Array<String>) {
    run { println(42) }
}
