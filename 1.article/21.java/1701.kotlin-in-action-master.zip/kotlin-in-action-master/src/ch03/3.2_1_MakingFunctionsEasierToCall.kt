package ch03.ex2_1_MakingFunctionsEasierToCall

fun main(args: Array<String>) {
    val list = listOf(1, 2, 3)
    println(list)
}
